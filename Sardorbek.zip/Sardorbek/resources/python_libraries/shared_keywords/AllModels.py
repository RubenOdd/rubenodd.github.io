# This file (AllModels.py) is updated automatically on import.
# All changes made to this file by user will be lost on update.
from qautomatelibrary.ProjectUtils import ProjectUtils
try:
    dynamic_classes = ProjectUtils().load_modules(__file__)
finally: ProjectUtils().update_source(__file__)

class AllModels(
            *dynamic_classes,
        ):
    def __init__(self):
        pass
