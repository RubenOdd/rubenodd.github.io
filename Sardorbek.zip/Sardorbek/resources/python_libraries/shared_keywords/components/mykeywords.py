from robot.api.deco import keyword
from qautomatelibrary.BrowserExtension import BrowserExtension
#from shared_keywords.AllModels import AllModels
browser = BrowserExtension()
#model_keywords = AllModels()
class component:

    CLICK_DIVCLASSFORMLOGFORMINPUT1 = "//h3[contains(text(),'Login')]/following::input[1]"
    CLICK_DIVCLASSFORMLOGFORMINPUT2 = "//div[@class='form-log']/descendant::input[@type='password']"
    CLICK_DIVCLASSFORMLOGFORMINPUT3 = "//h3[contains(text(),'Login')]/following::input[3]"
    FILL_TEXT_NOTE = "//input[@name='note']"
    CLICK_DIVCLASSFORMADDINGFORMINPUT3 = "//div[@id='root']/descendant::input[@type='submit']"
    CLICK_DIVCLASSAPPDIVDIVULLI5 = "//div[@class='notes-container']/ul/li[contains(text(), 'Dumbo')]"
    CLICK_DELETE = "//div[@class='notes-container']/ul/li[contains(text(), 'Dumbo')]/button"
    CLICK_BUTTONTEXTLOGOUT = "//div[@id='root']/descendant::button[contains(text(),'Logout')]"

    def __init__(self):
        """
        Pagemodel initialization
        """
        pass


    @keyword
    def Login(self,divclassformlogforminput1,divclassformlogforminput2):

        browser.fill_text(selector=self.CLICK_DIVCLASSFORMLOGFORMINPUT1, txt=str(divclassformlogforminput1))
        browser.fill_text(selector=self.CLICK_DIVCLASSFORMLOGFORMINPUT2, txt=str(divclassformlogforminput2))
        browser.click(selector=self.CLICK_DIVCLASSFORMLOGFORMINPUT3)


    @keyword
    def InputNewNote(self,fill_text_note):

        browser.fill_text(selector=self.FILL_TEXT_NOTE, txt=str(fill_text_note))
        browser.click(selector=self.CLICK_DIVCLASSFORMADDINGFORMINPUT3)


    @keyword
    def ChangeNewNote(self):

        browser.click(selector=self.CLICK_DIVCLASSAPPDIVDIVULLI5)


    @keyword
    def DeleteNewNote(self):

        browser.click(selector=self.CLICK_DELETE)

    @keyword
    def Logout(self):

        browser.click(selector=self.CLICK_BUTTONTEXTLOGOUT)

