# This file (AllComponents.py) is updated automatically on import.
# All changes made to this file by user will be lost on update.
from qautomatelibrary.ProjectUtils import ProjectUtils
try:
    from shared_keywords.components import mykeywords
    dynamic_classes = ProjectUtils().load_modules(__file__)
finally: ProjectUtils().update_source(__file__)

class AllComponents(
            *dynamic_classes,
            mykeywords.component,
        ):
    def __init__(self):
        pass
